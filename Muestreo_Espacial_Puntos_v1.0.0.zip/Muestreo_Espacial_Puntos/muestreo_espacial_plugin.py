# -*- coding: utf-8 -*-
"""
Complemento QGIS: Muestreo_Espacial_Puntos
Clase principal — registra proveedor Processing, menú y barra de herramientas.
"""

import os
from qgis.core import QgsApplication, QgsProcessingAlgorithm
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon
from .processing_provider import MuestreoEspacialProvider


class MuestreoEspacialPlugin:
    """Clase principal del complemento Muestreo Espacial de Puntos.

    Registra:
      - Proveedor de algoritmos de Processing (Toolbox)
      - Entrada en menú Complementos
      - Botón en barra de herramientas con ícono
    """

    MENU_TITLE = 'Muestreo Espacial de Puntos'
    ALG_ID     = 'muestreo_espacial_puntos:muestreo_espacial_puntos_v1_0_0'

    def __init__(self, iface):
        self.iface    = iface
        self.provider = None
        self.action   = None
        self.toolbar  = None

    # ------------------------------------------------------------------
    def initGui(self):
        """Activa el complemento: proveedor + menú + barra de herramientas."""

        # 1. Registrar proveedor de Processing
        self.provider = MuestreoEspacialProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        # 2. Ícono desde la carpeta del plugin
        plugin_dir = os.path.dirname(__file__)
        icon_path  = os.path.join(plugin_dir, 'icon.png')
        icon       = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        # 3. QAction — abre el diálogo del algoritmo directamente
        self.action = QAction(icon, self.MENU_TITLE, self.iface.mainWindow())
        self.action.setToolTip(
            'Muestreo Espacial de Puntos — '
            'Sistemático Hilbert, Grupos Hilbert, Aleatorio, K-Medias'
        )
        self.action.setStatusTip(self.MENU_TITLE)
        self.action.triggered.connect(self._run_algorithm)

        # 4. Agregar al menú Complementos
        self.iface.addPluginToMenu(self.MENU_TITLE, self.action)

        # 5. Crear barra de herramientas propia con ícono
        self.toolbar = self.iface.addToolBar(self.MENU_TITLE)
        self.toolbar.setObjectName('MuestreoEspacialPuntosToolBar')
        self.toolbar.addAction(self.action)

    # ------------------------------------------------------------------
    def unload(self):
        """Desactiva el complemento: elimina menú, toolbar y proveedor."""

        if self.action:
            self.iface.removePluginMenu(self.MENU_TITLE, self.action)
            self.action = None

        if self.toolbar:
            self.toolbar.deleteLater()
            self.toolbar = None

        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None

    # ------------------------------------------------------------------
    def _run_algorithm(self):
        """Abre el diálogo de Processing para el algoritmo principal."""
        try:
            from qgis import processing
            processing.execAlgorithmDialog(self.ALG_ID)
        except Exception as e:
            # Fallback: abrir el panel de Procesos si el diálogo falla
            try:
                self.iface.mainWindow().findChild(
                    __import__('qgis.PyQt.QtWidgets', fromlist=['QDockWidget'])
                    .QDockWidget, 'ProcessingToolbox'
                ).setVisible(True)
            except Exception:
                QMessageBox.information(
                    self.iface.mainWindow(),
                    self.MENU_TITLE,
                    'Abra el panel de Procesos (Procesos → Caja de herramientas) '
                    'y busque "Muestreo Espacial de Puntos".\n\n'
                    f'Error al abrir diálogo: {e}'
                )
